package second.mongodb;

import org.bson.types.ObjectId;

import second.mongodb.domain.entity.Member;
import second.mongodb.service.MemberService;

public class MainTest {

	MemberService memberService = new MemberService();
	
	//--------------------- 입력하기
	void insert(){
		
	}
	
	//------------------- 컬렉션 목록 조회
	void findAll(){
			
	}
	
	void findById(){
	
	} 
	
	void update(){

	}
	
	void delete(){

	}
	
	public static void main(String[] args) {
		MainTest test = new MainTest();
		//test.insert();
		//test.findAll();
		//test.findById();
		//test.update();
		//test.delete();
	}

}
